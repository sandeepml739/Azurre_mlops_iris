python --version
#pip install --upgrade azure-cli
pip install azure-cli==2.20.0
pip install --upgrade azureml-sdk[cli]
pip install pytest
pip install pytest-cov
#pip install -r requirements.txt
